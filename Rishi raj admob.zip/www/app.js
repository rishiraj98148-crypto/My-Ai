const WORKER_URL =
  "https://rishi-ai-api.rishiraj98148.workers.dev";

let currentChat = [];
let voiceReplyEnabled = true;


// =========================================================
// ADMOB BANNER
// =========================================================
//
// Development मा Google TEST banner प्रयोग गरिएको छ.
// Live AdMob ID testing मा प्रयोग नगर्नुहोस्.
//
// Test Android Banner:
// ca-app-pub-3940256099942544/6300978111
//
// Test सफल भएपछि तल TEST_BANNER_AD_ID लाई
// आफ्नो AdMob Banner Ad Unit ID ले replace गर्नुहोस्
// र isTesting लाई false गर्नुहोस्.
// =========================================================

const TEST_BANNER_AD_ID =
  "ca-app-pub-3940256099942544/6300978111";

const AdMobPlugin =
  window.Capacitor?.Plugins?.AdMob || null;

let adMobStarted = false;


async function startAdMobBanner() {

  // Normal browser/web mode मा native AdMob हुँदैन.
  if (!AdMobPlugin) {

    console.log(
      "AdMob: native plugin not available. Running in web mode."
    );

    return;
  }


  if (adMobStarted) {
    return;
  }


  try {

    // Initialize AdMob
    await AdMobPlugin.initialize();


    // Request privacy/consent information
    let consentInfo =
      await AdMobPlugin.requestConsentInfo();


    // Show consent form if Google requires it
    if (
      consentInfo?.isConsentFormAvailable &&
      consentInfo?.status === "REQUIRED"
    ) {

      consentInfo =
        await AdMobPlugin.showConsentForm();

    }


    // Do not request ads until Google allows it
    if (
      !consentInfo ||
      !consentInfo.canRequestAds
    ) {

      console.log(
        "AdMob: consent is not ready. Banner not shown."
      );

      return;
    }


    // Show Google TEST Banner
    await AdMobPlugin.showBanner({

      adId:
        TEST_BANNER_AD_ID,

      adSize:
        "ADAPTIVE_BANNER",

      position:
        "BOTTOM_CENTER",

      margin:
        0,

      isTesting:
        true

    });


    adMobStarted = true;


    console.log(
      "AdMob: test banner shown successfully."
    );


  } catch (error) {

    console.error(
      "AdMob banner error:",
      error
    );

  }

}


// =========================================================
// ADMOB PRIVACY SETTINGS
// =========================================================

async function openAdPrivacySettings() {

  if (!AdMobPlugin) {

    alert(
      "Ad privacy settings are available in the Android app."
    );

    return;
  }


  try {

    await AdMobPlugin.showPrivacyOptionsForm();

  } catch (error) {

    console.error(
      "Ad privacy settings error:",
      error
    );

  }

}


// =========================================================
// ELEMENTS
// =========================================================

const chatArea =
  document.getElementById("chatArea");

const messageInput =
  document.getElementById("messageInput");

const sendBtn =
  document.getElementById("sendBtn");

const micBtn =
  document.getElementById("micBtn");


const menuBtn =
  document.getElementById("menuBtn");

const closeMenuBtn =
  document.getElementById("closeMenuBtn");

const sideMenu =
  document.getElementById("sideMenu");

const overlay =
  document.getElementById("overlay");


const newChatBtn =
  document.getElementById("newChatBtn");

const sideNewChat =
  document.getElementById("sideNewChat");


const historyList =
  document.getElementById("historyList");


const themeBtn =
  document.getElementById("themeBtn");

const voiceReplyBtn =
  document.getElementById("voiceReplyBtn");


const loginScreen =
  document.getElementById("loginScreen");

const app =
  document.getElementById("app");


const loginName =
  document.getElementById("loginName");

const loginEmail =
  document.getElementById("loginEmail");

const loginBtn =
  document.getElementById("loginBtn");


const logoutBtn =
  document.getElementById("logoutBtn");

const privacyAdBtn =
  document.getElementById("privacyAdBtn");


const userName =
  document.getElementById("userName");

const userEmail =
  document.getElementById("userEmail");


// =========================================================
// LOGIN
// =========================================================

function checkLogin() {

  const user =
    localStorage.getItem("myAIUser");


  if (user) {

    try {

      const data =
        JSON.parse(user);

      showApp(data);

    } catch (error) {

      localStorage.removeItem("myAIUser");

      loginScreen.classList.remove("hidden");

      app.classList.add("hidden");

    }

  } else {

    loginScreen.classList.remove("hidden");

    app.classList.add("hidden");

  }

}


function showApp(data) {

  loginScreen.classList.add("hidden");

  app.classList.remove("hidden");


  userName.textContent =
    data.name || "User";

  userEmail.textContent =
    data.email || "user@email.com";


  loadHistory();

}


loginBtn.addEventListener(
  "click",
  () => {

    const name =
      loginName.value.trim();

    const email =
      loginEmail.value.trim();


    if (!name || !email) {

      alert(
        "Please enter your name and email."
      );

      return;
    }


    const user = {

      name:
        name,

      email:
        email

    };


    localStorage.setItem(
      "myAIUser",
      JSON.stringify(user)
    );


    showApp(user);

  }
);


logoutBtn.addEventListener(
  "click",
  () => {

    if (
      !confirm(
        "Do you want to logout?"
      )
    ) {

      return;

    }


    localStorage.removeItem(
      "myAIUser"
    );


    location.reload();

  }
);


// =========================================================
// ADMOB PRIVACY BUTTON
// =========================================================

if (privacyAdBtn) {

  privacyAdBtn.addEventListener(
    "click",
    openAdPrivacySettings
  );

}


// =========================================================
// DARK MODE
// =========================================================

function loadTheme() {

  const theme =
    localStorage.getItem("myAITheme");


  if (theme === "dark") {

    document.body.classList.add("dark");

    themeBtn.textContent =
      "☀️";

  } else {

    document.body.classList.remove("dark");

    themeBtn.textContent =
      "🌙";

  }

}


themeBtn.addEventListener(
  "click",
  () => {

    document.body.classList.toggle(
      "dark"
    );


    const dark =
      document.body.classList.contains(
        "dark"
      );


    localStorage.setItem(
      "myAITheme",
      dark ? "dark" : "light"
    );


    themeBtn.textContent =
      dark ? "☀️" : "🌙";

  }
);


// =========================================================
// NATIVE AI VOICE REPLY
// =========================================================

const Capacitor =
  window.Capacitor;


const NativeTTS =
  Capacitor?.Plugins?.TextToSpeech ||
  null;


voiceReplyBtn.addEventListener(
  "click",
  async () => {

    voiceReplyEnabled =
      !voiceReplyEnabled;


    voiceReplyBtn.textContent =
      voiceReplyEnabled
        ? "🔊"
        : "🔇";


    if (
      !voiceReplyEnabled &&
      NativeTTS
    ) {

      try {

        await NativeTTS.stop();

      } catch (e) {}

    }

  }
);


async function speakAI(text) {

  if (!voiceReplyEnabled) {
    return;
  }


  const cleanText =
    text
      .replace(/[*#`]/g, "")
      .replace(/<[^>]*>/g, "")
      .trim();


  if (!cleanText) {
    return;
  }


  if (NativeTTS) {

    try {

      await NativeTTS.stop();


      await NativeTTS.speak({

        text:
          cleanText,

        lang:
          "en-US",

        rate:
          0.95,

        pitch:
          1.0,

        volume:
          1.0,

        queueStrategy:
          0

      });


      return;

    } catch (e) {

      console.warn(
        "Native TTS failed:",
        e
      );

    }

  }


  if (
    "speechSynthesis"
    in window
  ) {

    window.speechSynthesis.cancel();


    const speech =
      new SpeechSynthesisUtterance(
        cleanText
      );


    speech.lang =
      "en-US";

    speech.rate =
      0.95;

    speech.pitch =
      1;


    window.speechSynthesis.speak(
      speech
    );

  }

}


// =========================================================
// MARKDOWN FORMATTER
// =========================================================

function escapeHTML(text) {

  return text
    .replace(
      /&/g,
      "&amp;"
    )
    .replace(
      /</g,
      "&lt;"
    )
    .replace(
      />/g,
      "&gt;"
    );

}


function formatAIText(text) {

  let html =
    escapeHTML(text);


  // Code blocks
  html =
    html.replace(
      /```([\s\S]*?)```/g,
      '<pre class="code-block"><code>$1</code></pre>'
    );


  // Headings
  html =
    html.replace(
      /^### (.*)$/gm,
      "<h4>$1</h4>"
    );


  html =
    html.replace(
      /^## (.*)$/gm,
      "<h3>$1</h3>"
    );


  html =
    html.replace(
      /^# (.*)$/gm,
      "<h2>$1</h2>"
    );


  // Bold
  html =
    html.replace(
      /\*\*(.*?)\*\*/g,
      "<strong>$1</strong>"
    );


  // Italic
  html =
    html.replace(
      /(?<!\*)\*(?!\*)(.*?)\*(?!\*)/g,
      "<em>$1</em>"
    );


  // Numbered list
  html =
    html.replace(
      /^(\d+)\.\s+(.*)$/gm,
      '<div class="number-item"><span class="number">$1.</span><span>$2</span></div>'
    );


  // Bullet list
  html =
    html.replace(
      /^[*-]\s+(.*)$/gm,
      '<div class="bullet-item"><span class="bullet">•</span><span>$1</span></div>'
    );


  // Inline code
  html =
    html.replace(
      /`([^`]+)`/g,
      "<code>$1</code>"
    );


  // New lines
  html =
    html.replace(
      /\n/g,
      "<br>"
    );


  return html;

}


// =========================================================
// ADD MESSAGE
// =========================================================

function addMessage(
  text,
  type
) {

  const welcome =
    document.getElementById(
      "welcome"
    );


  if (welcome) {
    welcome.remove();
  }


  const message =
    document.createElement(
      "div"
    );


  message.className =
    "message " +
    (
      type === "user"
        ? "user-message"
        : "ai-message"
    );


  const avatar =
    document.createElement(
      "div"
    );


  avatar.className =
    "avatar";


  avatar.textContent =
    type === "user"
      ? "👤"
      : "✦";


  const content =
    document.createElement(
      "div"
    );


  content.className =
    "message-content";


  if (type === "user") {

    content.textContent =
      text;

  } else {

    content.innerHTML =
      formatAIText(text);

  }


  message.appendChild(
    avatar
  );


  message.appendChild(
    content
  );


  chatArea.appendChild(
    message
  );


  // Copy button for AI
  if (type === "ai") {

    const copyBtn =
      document.createElement(
        "button"
      );


    copyBtn.className =
      "copy-btn";


    copyBtn.textContent =
      "📋 Copy";


    copyBtn.onclick =
      async () => {

        try {

          await navigator.clipboard.writeText(
            text
          );

          copyBtn.textContent =
            "✅ Copied";

        } catch (error) {

          copyBtn.textContent =
            "❌ Copy failed";

        }


        setTimeout(
          () => {

            copyBtn.textContent =
              "📋 Copy";

          },
          1500
        );

      };


    content.appendChild(
      document.createElement(
        "br"
      )
    );


    content.appendChild(
      copyBtn
    );

  }


  chatArea.scrollTop =
    chatArea.scrollHeight;

}


// =========================================================
// SEND MESSAGE
// =========================================================

async function sendMessage() {

  const message =
    messageInput.value.trim();


  if (!message) {
    return;
  }


  addMessage(
    message,
    "user"
  );


  currentChat.push({

    role:
      "user",

    content:
      message

  });


  messageInput.value =
    "";


  messageInput.style.height =
    "auto";


  const loading =
    document.createElement(
      "div"
    );


  loading.className =
    "message ai-message";


  loading.innerHTML = `
    <div class="avatar">✦</div>
    <div class="message-content">
      Thinking...
    </div>
  `;


  chatArea.appendChild(
    loading
  );


  chatArea.scrollTop =
    chatArea.scrollHeight;


  try {

    const response =
      await fetch(
        WORKER_URL,
        {

          method:
            "POST",

          headers: {

            "Content-Type":
              "application/json"

          },

          body:
            JSON.stringify({

              message:
                message

            })

        }
      );


    const data =
      await response.json();


    loading.remove();


    if (!response.ok) {

      throw new Error(
        data.error ||
        "AI request failed"
      );

    }


    const reply =
      data.reply ||
      "No response received.";


    addMessage(
      reply,
      "ai"
    );


    currentChat.push({

      role:
        "assistant",

      content:
        reply

    });


    saveCurrentChat();


    speakAI(
      reply
    );


  } catch (error) {

    loading.remove();


    addMessage(
      "❌ Error: " +
      error.message,
      "ai"
    );

  }

}


sendBtn.addEventListener(
  "click",
  sendMessage
);


// =========================================================
// ENTER TO SEND
// =========================================================

messageInput.addEventListener(
  "keydown",
  (event) => {

    if (
      event.key === "Enter" &&
      !event.shiftKey
    ) {

      event.preventDefault();

      sendMessage();

    }

  }
);


// =========================================================
// AUTO RESIZE
// =========================================================

messageInput.addEventListener(
  "input",
  () => {

    messageInput.style.height =
      "auto";


    messageInput.style.height =
      Math.min(
        messageInput.scrollHeight,
        130
      ) + "px";

  }
);


// =========================================================
// NATIVE VOICE INPUT
// =========================================================

const NativeSpeech =
  Capacitor?.Plugins?.SpeechRecognition ||
  null;


let listening =
  false;


async function startNativeVoice() {

  if (!NativeSpeech) {

    alert(
      "Voice input is not available in this APK build."
    );

    return;
  }


  try {

    const permission =
      await NativeSpeech.checkPermissions();


    if (
      permission?.speechRecognition !==
      "granted"
    ) {

      const requested =
        await NativeSpeech.requestPermissions();


      if (
        requested?.speechRecognition !==
        "granted"
      ) {

        alert(
          "Microphone permission is required for voice input."
        );

        return;

      }

    }


    const available =
      await NativeSpeech.available();


    if (
      !available?.available
    ) {

      alert(
        "Speech recognition is not available on this phone."
      );

      return;

    }


    listening =
      true;


    micBtn.classList.add(
      "listening"
    );


    micBtn.textContent =
      "⏹️";


    const result =
      await NativeSpeech.start({

        language:
          "en-US",

        maxResults:
          1,

        prompt:
          "Speak to My AI",

        partialResults:
          false,

        popup:
          true

      });


    const text =
      result?.matches?.[0] ||
      "";


    if (text) {

      messageInput.value =
        text;


      messageInput.dispatchEvent(
        new Event("input")
      );

    }


  } catch (error) {

    console.error(
      "Voice input error:",
      error
    );


    alert(
      "Voice input could not start. Please allow microphone permission and try again."
    );


  } finally {

    listening =
      false;


    micBtn.classList.remove(
      "listening"
    );


    micBtn.textContent =
      "🎤";

  }

}


micBtn.addEventListener(
  "click",
  async () => {

    if (
      listening &&
      NativeSpeech
    ) {

      try {

        await NativeSpeech.stop();

      } catch (e) {}

      return;

    }


    await startNativeVoice();

  }
);


// =========================================================
// CHAT HISTORY
// =========================================================

function saveCurrentChat() {

  if (
    currentChat.length === 0
  ) {
    return;
  }


  const history =
    JSON.parse(
      localStorage.getItem(
        "myAIHistory"
      ) || "[]"
    );


  const firstUserMessage =
    currentChat.find(
      item =>
        item.role === "user"
    );


  if (!firstUserMessage) {
    return;
  }


  history.unshift({

    title:
      firstUserMessage.content
        .slice(0, 35),

    messages:
      currentChat,

    date:
      new Date().toLocaleString()

  });


  localStorage.setItem(
    "myAIHistory",
    JSON.stringify(
      history.slice(0, 20)
    )
  );


  loadHistory();

}


function loadHistory() {

  const history =
    JSON.parse(
      localStorage.getItem(
        "myAIHistory"
      ) || "[]"
    );


  historyList.innerHTML =
    "";


  history.forEach(
    (chat) => {

      const item =
        document.createElement(
          "div"
        );


      item.className =
        "history-item";


      item.textContent =
        chat.title ||
        "New Chat";


      item.onclick =
        () => {

          loadChat(
            chat
          );

          closeMenu();

        };


      historyList.appendChild(
        item
      );

    }
  );

}


function loadChat(chat) {

  chatArea.innerHTML =
    "";


  currentChat =
    [];


  chat.messages.forEach(
    (message) => {

      addMessage(
        message.content,
        message.role === "user"
          ? "user"
          : "ai"
      );


      currentChat.push(
        message
      );

    }
  );

}


// =========================================================
// NEW CHAT
// =========================================================

function newChat() {

  if (
    currentChat.length > 0
  ) {

    saveCurrentChat();

  }


  currentChat =
    [];


  chatArea.innerHTML = `
    <section
      class="welcome"
      id="welcome"
    >

      <img
        class="big-logo"
        src="assets/my-ai-icon.png"
        alt="My AI"
      >

      <h1>
        How can I help you?
      </h1>

      <p>
        Ask questions, learn, create and explore with My AI.
      </p>

      <div class="welcome-chips">

        <span>
          ✨ Smart
        </span>

        <span>
          🎤 Voice
        </span>

        <span>
          ⚡ Fast
        </span>

      </div>

    </section>
  `;

}


newChatBtn.addEventListener(
  "click",
  newChat
);


sideNewChat.addEventListener(
  "click",
  () => {

    newChat();

    closeMenu();

  }
);


// =========================================================
// SIDE MENU
// =========================================================

function openMenu() {

  sideMenu.classList.add(
    "open"
  );

  overlay.classList.add(
    "show"
  );

}


function closeMenu() {

  sideMenu.classList.remove(
    "open"
  );

  overlay.classList.remove(
    "show"
  );

}


menuBtn.addEventListener(
  "click",
  openMenu
);


closeMenuBtn.addEventListener(
  "click",
  closeMenu
);


overlay.addEventListener(
  "click",
  closeMenu
);


// =========================================================
// SPLASH SCREEN
// =========================================================

setTimeout(
  () => {

    const splash =
      document.getElementById(
        "splashScreen"
      );


    if (splash) {

      splash.classList.add(
        "hide"
      );

    }

  },
  1100
);


// =========================================================
// START APP
// =========================================================

loadTheme();

checkLogin();


// Start AdMob after UI is ready
setTimeout(
  () => {

    startAdMobBanner();

  },
  1500
);

